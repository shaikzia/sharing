# 1. Given a list, url = [www.annauniv.edu, www.google.com, www.ndtv.com, www.website.org, www.bis.org.in, www.rbi.org.in]
# Sort the list based on the top level domain (edu, com, org, in) using custom sorting

import tldextract
import operator 

def sort_url():
    keys = []
    values = []
    url = ['www.annauniv.edu', 'www.google.com', 'www.ndtv.com', 'www.website.org', 'www.bis.org.in', 'www.rbi.org.in']
    for u in url:
        extracted_domain = tldextract.extract(u)
        k = extracted_domain.domain
        v = extracted_domain.suffix
        k = 'www.' + k
        keys.append(k)
        values.append(v)

    dic = dict(zip(keys,values))
    sorted_dic = sorted(dic.items(), key=operator.itemgetter(1))
    print([str('.'.join(str(i) for i in x)) for x in sorted_dic])


if __name__ == '__main__':
    sort_url()
