# 2. Given a list of strings, return the count of the number of strings where the string length is 2 or more and the 
# first and last chars of the string are the same.  
#    i. ['axa', 'xyz', 'gg', 'x', 'yyy']
#    ii. ['x', 'cd', 'cnc', 'kk']
#    iii. ['bab', 'ce', 'cba', 'syanora']

# Executable command from terminal - python 02_count_strings.py "['axa', 'xyz', 'gg', 'x', 'yyy']"


import sys,ast

l = ast.literal_eval( sys.argv[1] )


def count_strings(l):
    new_l = []
    for i in l:
        if len(i) >= 2 and i[0] == i[-1]:
            new_l.append(i)
    print(len(new_l))


if __name__ == '__main__':
    count_strings(l)
