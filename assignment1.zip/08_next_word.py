#     8. Given a string,
# Hint:  Assume that the first word is preceded by " "
#        a. Build a dictionary where the key is a word and the value is the list of words that are likely to follow.
#            i. E.g. Python  [is, has, features, interpreters, code, Software]. In this example the words listed are likely to follow “Python”
#        b. Given a word predict the word that’s likely to follow.

import sys
str8 = """Python is a widely used high-level programming language for general-purpose programming, created by Guido van Rossum and first released in 1991. An interpreted language, Python has a design philosophy which emphasizes code readability (notably using whitespace indentation to delimit code blocks rather than curly braces or keywords), and a syntax which allows programmers to express concepts in fewer lines of code than possible in languages such as C++ or Java. The language provides constructs intended to enable writing clear programs on both a small and large scale. Python features a dynamic type system and automatic memory management and supports multiple programming paradigms, including object-oriented, imperative, functional programming, and procedural styles. It has a large and comprehensive standard library. Python interpreters are available for many operating systems, allowing Python code to run on a wide variety of systems. CPython, the reference implementation of Python, is open source software and has a community-based development model, as do nearly all of its variant implementations. CPython is managed by the non-profit Python Software Foundation."""

def print_dict():
    result = {}
    v = []
    for special in ".,-_*\(!#+<>]|)":
        text = str8.replace(special, ' ')
        text = text.split()

    for i in range(len(text)-1):
        k = text[i] 
        v = text[i+1]
        result.setdefault(k, []).append(v)
    print(result)

def next_word(givenword):
    words = str8.split()
    new_list = []
    next_words = []
    words_list = []
    key_list = []
    special_chars = ".,-_*\( !#+<>]|)"

    for word in words:
        word = word.strip(special_chars)
        new_list.append(word)
    
    for i,w in enumerate(new_list):
        if w == givenword:
            next_words.append(words[i+1])
            words_list.append(next_words)

    key_list.append(givenword)
    dic_words = dict(zip(key_list, words_list))
    print(dic_words)

def run_program():
    if len(sys.argv) == 2:
        givenword = sys.argv[1]
        next_word(givenword)    
    elif len(sys.argv) == 1:
        print_dict()
    else:
        print("No Output to display")

if __name__ =='__main__':
    run_program()
