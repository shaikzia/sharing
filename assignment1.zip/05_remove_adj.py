# 5. Given a list of numbers, return a list where all adjacent == elements have been reduced to a single element, 
# so [1, 2, 2, 3] returns [1, 2, 3]. You may create a new list or modify the passed in list.
#    i.  [1, 2, 2, 3], [2, 2, 3, 3, 3]

# Executable command from terminal - python 05_remove_adj.py "[ '1', '2', '2', '3']"

import sys
import ast
from itertools import groupby

l2 = []
l1 = ast.literal_eval(sys.argv[1])

def remove_adj(l1):
    n = [x[0] for x in groupby(l1)]

    for i in n:
       l2.append(int(i))
   
    print(l2)

if __name__ == '__main__':
    remove_adj(l1)
