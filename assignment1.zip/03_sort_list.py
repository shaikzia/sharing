# 3. Given a list of strings, return a list with the strings in sorted order, except group all the strings that begin with 'x' first. 
# e.g. ['mix',  'xyz', 'apple', 'xanadu', 'aardvark'] yields
# ['xanadu', 'xyz', 'aardvark', 'apple', 'mix']. 
# Hint: this can be done by making 2 lists and sorting each of them before combining them.

## Executable command from terminal - python 03_sort_list.py "['mix',  'xyz', 'apple', 'xanadu', 'aardvark']"

import sys, ast

l = ast.literal_eval(sys.argv[1])

# 'mix' 'xyz' 'apple' 'xanadu' 'aardvark'

def sort_list(l):
    l1 = []
    l2 = []
    l3 = []
    for i in l:
        if i[0] == 'x':
            l1.append(i)
            l1.sort()
        else:
            l2.append(i)
            l2.sort()
    l3 = l1 + l2
    print(l3)


if __name__ == '__main__':
    sort_list(l)
