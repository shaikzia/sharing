# 6. Write a function to print the information in the dictionary(bookstore) in the given format
# bookstore={"New Arrivals":{"COOKING":["Everyday Italian","Giada De Laurentiis","2005","30.00"],"CHILDREN":["Harry Potter”, J K. 
# Rowling","2005","29.99"],"WEB":["Learning XML","Erik T. Ray","2003","39.95"]}}


bookstore = {"New Arrivals":{"COOKING":["Everyday Italian", "Giada De Laurentis", "2005", "30.00"],
                             "CHILDREN":["Harry Potter", "J.K Rowling", "2005", "29.99"],
                             "WEB":["Learning XML", "Erik T.Ray", "2003", "39.95"]
                            }
            }

def print_info(d):
    print("\nBOOKSTORE\n")
    for v1 in d.values():
        for v2 in v1.values():
            strn=str(v2)
            print(strn)



if __name__ == '__main__':
    print_info(bookstore)
