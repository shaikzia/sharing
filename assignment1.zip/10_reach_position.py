#    10. Given a number line from -infinity to +infinity. You start at 0 and can go either to the left or to the right. The condition is that in i’th # move, you take i steps. In the first move take 1 step, second move 2 steps and so on. 
# Hint: 3 can be reached in 2 steps (0, 1) (1, 3). 2 can be reached in 3 steps (0, 1) (1,-1) (-1, 2)
# a) Find the optimal number of steps to reach position 1000000000 and -1000000000.  

# Executable command from terminal 

import sys

number = sys.argv[1]
number = int(number)

def reach(number) : 
  
    position = abs(number) 
    sum = 0
    step = 0
    while (sum < number or (sum - number) % 2 != 0) : 
        step = step + 1
        sum = sum + step 
      
    print(step)

if __name__ == '__main__':
    reach(number)
